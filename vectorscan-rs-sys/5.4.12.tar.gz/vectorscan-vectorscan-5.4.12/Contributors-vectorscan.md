   549	Konstantinos Margaritis <konstantinos@vectorcamp.gr>
    78  George Economou <george.economou@vectorcamp.gr>
    71  George Tsoulkanakis <george.tsoulkanakis@vectorcamp.gr>
    59	apostolos <apostolos.tapsas@vectorcamp.gr>
    25	Hong, Yang A <yang.a.hong@intel.com>
    19	George Wort <george.wort@arm.com>
    16	Chang, Harry <harry.chang@intel.com>
     7	Danila Kutenin <danilak@google.com>
     7	Wang Xiang W <xiang.w.wang@intel.com>
     6	Alex Bondarev <abondarev84@gmail.com>
     6  Yoan Picchi <yoan.picchi@arm.com>
     5  Jeremy Linton <jeremy.linton@arm.com>
     3	Duncan Bellamy <dunk@denkimushi.com>
     2	Azat Khuzhin <a3at.mail@gmail.com>
     2	Jan Henning <jan.thilo.henning@sap.com>
     1	BigRedEye <mail@bigredeye.me>
     1  Brad Larsen <bradford.larsen@praetorian.com>
     1  Chrysovalantis - Michail Liakopoulos <valadis.liakopoulos@vectorcamp.gr>
     1	Daniel Kutenin <kutdanila@yandex.ru>
     1	Danila Kutenin <kutdanila@yandex.ru>
     1  HelixHexagon <60048780+HelixHexagon@users.noreply.github.com>
     1  Jingbo Chen <cj@yanhuangdata.com>
     1	Liu Zixian <hdu_sdlzx@163.com>
     1  Matthias Gliwka <matthias@gliwka.eu>
     1  Michael Tremer <michael.tremer@ipfire.org>
     1	Mitchell Wasson <miwasson@cisco.com>
     1	Piotr Skamruk <piotr.skamruk@gmail.com>
     1  Rafał Dowgird <dowgird@gmail.com>
     1	Robbie Williamson <robbie.williamson@arm.com>
     1	Robert Schulze <robert@clickhouse.com>
     1	Walt Stoneburner <wls@wwco.com>
     1	Zhu,Wenjun <wenjun.zhu@intel.com>
     1	hongyang7 <yang.a.hong@intel.com>
     1  ibrkas01arm <ibrahim.kashif@arm.com>
     1	jplaisance <jeffplaisance@gmail.com>
     1	liquidaty <info@liquidaty.com>
