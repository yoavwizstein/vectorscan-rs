Hyperscan Benchmarker: hsbench
==============================

The `hsbench` tool provides an easy way to measure Hyperscan's performance
for a particular set of patterns and corpus of data to be scanned.

Documentation describing its operation is available in the Tools section of the
[Developer Reference Guide](http://intel.github.io/hyperscan/dev-reference/).
